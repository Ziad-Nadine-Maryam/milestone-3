package activity;

public class Shop {
    public int id;
    public String name;
    public double price;
    public double distance;
    public String pname;
    public String special;
    public double lat;
    public double lgt;
    public int pid;





    public Shop(){
        this.id=id;
        this.name=name;
        this.price=price;
        this.distance=distance;
        this.pname=pname;
        this.special=special;
    }








}
