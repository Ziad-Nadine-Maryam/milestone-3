package activity;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);


}
