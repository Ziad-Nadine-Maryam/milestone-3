package activity;



import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import app.AppController;


import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.shoppy.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static activity.List2Activity.db;
import static activity.List2Activity.shopAttributes;


public class CartList extends AppCompatActivity {
    ListView SubjectListView;
    Button MYCART;
    Button shop;
    String tag_string_req = "req_login";
    String Server = "http://192.168.100.54/android_login_api/cartGet.php";



    public static  ArrayList<Cart> shopList = new ArrayList<Cart>();
    public static ArrayList<Cart> CartList = new ArrayList<Cart>();




    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cart);
        MYCART = (Button) findViewById(R.id.button3);
        shop = (Button) findViewById(R.id.button4);

        // final ListView list = findViewById(R.id.listview);
        SubjectListView = (ListView) findViewById(R.id.listview1);


        MYCART.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),
                        CartList.class);
                startActivity(i);
                finish();
            }
        });
        shop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),
                        ListActivity.class);
                startActivity(i);
                finish();
            }
        });
        StringRequest str = new StringRequest(Request.Method.POST,
                Server, new Response.Listener<String>() {
            @Override ///// shop table
            public void onResponse(String response) {
                System.out.println("Here!");


                try {

                    JSONArray y = new JSONArray(response);
                    JSONObject jObj;

                        for (int j = 0; j < y.length(); j++) {
                            Log.d("Dinaaaaaaaaaaaaaaa","lllllllllllllllllllllllllllllllll");
                            Cart myCart = new Cart();
                                jObj = y.getJSONObject(j);
                                myCart.User_Id=Integer.parseInt(jObj.getString("User_Id"));
                                myCart.shop_id=Integer.parseInt(jObj.getString("shop_id"));
                                myCart.product_id=Integer.parseInt(jObj.getString("product_id"));
                                for (int i=0;i<List2Activity.shopAttributes.size();i++){
                                    if(myCart.product_id==shopAttributes.get(i).pid)
                                        myCart.product_name=shopAttributes.get(i).pname;
                                    if(myCart.shop_id==shopAttributes.get(i).id)
                                        myCart.shop_name=shopAttributes.get(i).name;
                                }
                               if(myCart.User_Id==MainActivity.userss[0])
                                    CartList.add(myCart);
                        }

                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                    System.out.println("Catch1");
                    Toast.makeText(getApplicationContext(), "Json error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }


            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("catch2");
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();
                //hideDialog();
            }

        });

        CartAdapter adapter = new activity.CartAdapter(shopList, getApplicationContext());
        SubjectListView.setAdapter(adapter);


        AppController.getInstance().addToRequestQueue(str, tag_string_req);
    }

    public static void AddToCart(final int User_Id, final int shop_id, final int product_id){
        String tag_string_req = "req_register";
        StringRequest strReqt = new StringRequest(Request.Method.POST,
                "http://192.168.100.54/android_login_api/cartInsert.php"  , new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jObj = new JSONObject(response);
                    boolean error = jObj.getBoolean("error");
                    if (!error) {
                        System.out.println("miroooooooooooooo");
                        jObj = new JSONObject(response);
                        JSONObject cart = jObj.getJSONObject("cart");
                        int User_Id = Integer.parseInt(cart.getString("User_Id"));
                        int shop_id = Integer.parseInt(cart.getString("shop_id"));
                        int product_id = Integer.parseInt(cart.getString("product_id"));
                        db.insertItem(User_Id,shop_id,product_id);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        },new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {

                //Toast.makeText(getApplicationContext(),
                // error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {
            protected Map<String, Integer> getParam() {
                // Posting params to register url
                Map<String, Integer> paramss = new HashMap<>();
                //Map<String,Integer> params= new HashMap<String, Integer>();
                paramss.put("User_Id", User_Id);
                paramss.put("shop_id", shop_id);
                paramss.put("product_id",product_id);



                return paramss;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReqt, tag_string_req);
    }
    public static void RemoveFromCart(final int User_Id, final int shop_id, final int product_id){
        String tag_string_req = "req_register";
        StringRequest strReqt = new StringRequest(Request.Method.POST,
                "http://192.168.100.54/android_login_api/cartDelete.php"  , new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jObj = new JSONObject(response);
                    boolean error = jObj.getBoolean("error");
                    if (error) {
                        System.out.println("miroooooooooooooo");
                        jObj = new JSONObject(response);
                        JSONObject cart = jObj.getJSONObject("cart");
                        int User_Id = Integer.parseInt(cart.getString("User_Id"));
                        int shop_id = Integer.parseInt(cart.getString("shop_id"));
                        int product_id = Integer.parseInt(cart.getString("product_id"));
                        db.insertItem(User_Id,shop_id,product_id);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        },new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {

                //Toast.makeText(getApplicationContext(),
                // error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {
            protected Map<String, Integer> getParam() {
                // Posting params to register url
                Map<String, Integer> paramss = new HashMap<>();
                //Map<String,Integer> params= new HashMap<String, Integer>();
                paramss.put("User_Id", User_Id);
                paramss.put("shop_id", shop_id);
                paramss.put("product_id",product_id);



                return paramss;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReqt, tag_string_req);
    }






}





