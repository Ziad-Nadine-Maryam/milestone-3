package activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import app.AppConfig;
import app.AppController;
import helper.SQLiteHandler;
import helper.SessionManager;


import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.shoppy.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class ListActivity extends AppCompatActivity {
    ListView SubjectListView;
    ProgressBar progressBarSubject;
    private ProgressDialog pDialog;
    private SessionManager session;
    private SQLiteHandler db;
    private product product;
    public ArrayList<product> shopList = new ArrayList<product>();
    public static String productName;
    public static int pid;


    String s;
    String ServerURL = "http://192.168.100.54/android_login_api/productfetch.php";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        // final ListView list = findViewById(R.id.listview);


        SubjectListView = (ListView) findViewById(R.id.listview1);
        SubjectListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3) {
                productName=shopList.get(position).name;
                pid=shopList.get(position).id;
                Intent intent=new Intent(ListActivity.this,List2Activity.class);
                System.out.println("Product Name is "+productName);
                startActivity(intent);
            }
        });



        String tag_string_req = "req_login";
        StringRequest strReq = new StringRequest(Request.Method.POST,
                ServerURL, new Response.Listener<String>() {


            @Override
            public void onResponse(String response) {


                try {


                    JSONArray x = new JSONArray(response);
                    System.out.println("Here!");
                    JSONObject jObj;





                   for (int i = 0; i < x.length(); i++) {
                        jObj = x.getJSONObject(i);
                        product=new product();
                        product.id = Integer.parseInt(jObj.getString("id"));
                        product.name = jObj.getString("name");
                        product.description = jObj.getString("description");
                        product.image_url = jObj.getString("image_url");
                        System.out.println("Print id " + product.id);
                        System.out.println("Print Name " + product.name);
                        System.out.println("Print description " + product.description);
                        System.out.println("Print image_url " + product.image_url);


                        shopList.add(product);


                    }
                    System.out.println("List size is "+shopList.size());
                    MyAdapter adapter = new MyAdapter(shopList, getApplicationContext());
                    SubjectListView.setAdapter(adapter);


                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                    System.out.println("Catch1");
                    Toast.makeText(getApplicationContext(), "Json error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }


            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("catch2");
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();
                //hideDialog();
            }

        });


        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);



    }



    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }







}


