package activity;

import java.util.Comparator;

public class PriceComparator implements Comparator<Shop> {

    @Override
    public int compare(Shop o1, Shop o2) {
        if(o2.price>=o1.price)
            return -1;
        else
            return 1;
    }
}
