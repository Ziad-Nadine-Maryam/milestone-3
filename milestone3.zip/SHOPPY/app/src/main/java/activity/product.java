package activity;

public class product {
    public int id;
    public String name;
    public String description;
    public String image_url;

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getImage_url() {
        return image_url;
    }

    public product() {
    }

}
