package activity;

public class Cart {
    public int User_Id;
    public int shop_id;
  public String shop_name;
    public int product_id;
    public String product_name;
}
