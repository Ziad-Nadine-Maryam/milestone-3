package activity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.shoppy.R;

import java.util.ArrayList;
import java.util.List;

public class MyAdapter extends BaseAdapter {

    Context context;
    List<product> valueList;
    List<product> valist;



    public MyAdapter(List<product> listValue, Context context)
    {
        this.context = context;
        this.valueList = listValue;
    }

    @Override
    public int getCount()
    {
        return this.valueList.size();
    }

    @Override
    public Object getItem(int position)
    {
        return this.valueList.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        ViewItem1 viewItem = null;

        if(convertView == null)
        {
            viewItem = new ViewItem1();

            LayoutInflater layoutInfiater = (LayoutInflater)this.context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);

            convertView = layoutInfiater.inflate(R.layout.rlist, null);

            viewItem.TextViewSubjectName = (TextView)convertView.findViewById(R.id.textView3);


            convertView.setTag(viewItem);
        }
        else
        {
            viewItem = (ViewItem1) convertView.getTag();
        }
        String s=toString(position);
        viewItem.TextViewSubjectName.setText(s);





        return convertView;
    }
    public  String toString( int position){
        return "Name: "+ valueList.get(position).name+" "+"Description: "+ valueList.get(position).description+"\n " +"\n "+ valueList.get(position).image_url+"\n " +"\n ";
    }

}

class ViewItem1
{
    TextView TextViewSubjectName;

}
