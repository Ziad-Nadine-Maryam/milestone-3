
package activity;
        import android.Manifest;
        import android.app.AlertDialog;
        import android.app.ProgressDialog;
        import android.content.DialogInterface;
        import android.content.Intent;
        import android.content.pm.PackageManager;
        import android.location.Location;
        import android.net.Uri;
        import android.os.Bundle;

        import androidx.annotation.NonNull;
        import androidx.appcompat.app.AppCompatActivity;
        import androidx.core.app.ActivityCompat;

        import app.AppController;
        import helper.SQLiteHandler;
        import helper.SessionManager;


        import android.util.Log;
        import android.view.View;
        import android.widget.AdapterView;
        import android.widget.Button;
        import android.widget.ListView;
        import android.widget.ProgressBar;
        import android.widget.Toast;

        import java.util.ArrayList;
        import java.util.HashMap;
        import java.util.Map;

        import com.android.volley.Request;
        import com.android.volley.Response;
        import com.android.volley.VolleyError;
        import com.android.volley.toolbox.StringRequest;
        import com.example.shoppy.R;
        import com.google.android.gms.location.FusedLocationProviderClient;
        import com.google.android.gms.location.LocationServices;
        import com.google.android.gms.tasks.OnSuccessListener;
        import com.google.android.gms.tasks.Task;

        import org.json.JSONArray;
        import org.json.JSONException;
        import org.json.JSONObject;


public class List2Activity extends AppCompatActivity {
    ListView SubjectListView;
    ProgressBar progressBarSubject;
    private ProgressDialog pDialog;
    private SessionManager session;
    public static SQLiteHandler db;
    private Shop shop;
    static Location currentLocation;
    static double lat;
    static double lgt;
    FusedLocationProviderClient fusedLocationProviderClient;
    private Button sortPrice;
    private Button sortDistance;
    private Button MyCart;
    private static final int REQUEST_CODE = 101;
    public ArrayList<Shop> shopList = new ArrayList<Shop>();
    public static  ArrayList<Shop> shopAttributes = new ArrayList<Shop>();
    String productName=ListActivity.productName;
    //public ArrayList<Shop> finalList = new ArrayList<Shop>();
    String s;
    public int User_Id =MainActivity.userss[0];
    public ArrayList<Shop> priceSorted = new ArrayList<Shop>();
    public ArrayList<Shop> distanceSorted = new ArrayList<Shop>();
    String ServerURL = "http://192.168.100.54/android_login_api/shopfetch.php";
    String Server = "http://192.168.100.54/android_login_api/distancefetch.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list2);
        // final ListView list = findViewById(R.id.listview);
        sortPrice = (Button) findViewById(R.id.priceSort);
        sortDistance = (Button) findViewById(R.id.distanceSort);
        MyCart = (Button) findViewById(R.id.button3);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        fetchLocation();
        User_Id=MainActivity.userss[0];


        SubjectListView = (ListView) findViewById(R.id.listview1);
        System.out.println("Check Product"+productName);
        /*SubjectListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                OnShopItemClick(position);
            }
        });*/







       String tag_string_req = "req_login";
         StringRequest strReq = new StringRequest(Request.Method.POST,
                ServerURL, new Response.Listener<String>() {


            @Override
            public void onResponse(String response) { ///shop_products table
                //shop=new Shop();


                try {

                    JSONArray x = new JSONArray(response);
                    JSONObject jObj;


                    for (int i = 0; i < x.length(); i++) {
                        jObj = x.getJSONObject(i);
                        shop=new Shop();
                        shop.pname=jObj.getString("product_name");
                        if(shop.pname.equals(productName)) {
                             shop.id= Integer.parseInt(jObj.getString("id"));
                            shop.name = jObj.getString("shop_name");

                            shop.price = Double.parseDouble(jObj.getString("price"));
                            shop.special = jObj.getString("special offers available");
                            //shop distance???
                            System.out.println("Print id " + shop.id);
                            System.out.println("Print Name " + shop.name);
                            System.out.println("Print price " + shop.price);
                            System.out.println("Print offer " + shop.special);

                            shopList.add(shop);
                        }

                        }


                    System.out.println("List size is "+shopList.size());
                    //NewAdapter adapter = new NewAdapter(shopList, getApplicationContext());
                   // SubjectListView.setAdapter(adapter);


                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                    System.out.println("Catch1");
                    Toast.makeText(getApplicationContext(), "Json error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }


            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("catch2");
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();
                //hideDialog();
            }

        });
        StringRequest str = new StringRequest(Request.Method.POST,
                Server, new Response.Listener<String>() {
            @Override ///// shop table
            public void onResponse(String response) {
                System.out.println("Here!");


                try {

                    JSONArray y = new JSONArray(response);
                    JSONObject jObj;

                    for(int k=0;k<shopList.size();k++) {
                        String name=shopList.get(k).name;
                        System.out.println("alllllllllllllllllllllllllllllllllllllllllllaaaaaaaaaaaaaaahhhhhhhhhhhhhhhhhh");
                        for (int j = 0; j < y.length(); j++) {
                            System.out.println("Henaaaasssssssssssssssssssssssssssssssssssssssssssssss");
                            if (y.getJSONObject(j).getString("name").equals(name)) {
                                System.out.println("Henaaaa");
                                Shop myShop = new Shop();
                                jObj = y.getJSONObject(j);
                                myShop.id=shopList.get(k).id;
                                myShop.name = jObj.getString("name");
                                myShop.special = shopList.get(k).special;
                                myShop.price = shopList.get(k).price;
                                Location A = new Location("shop");
                                A.setLatitude(jObj.getDouble("latitude"));
                                A.setLongitude(jObj.getDouble("longitude"));
                                myShop.lat=A.getLatitude();
                                myShop.lgt=A.getLongitude();
                                System.out.println(A.getLongitude());
                                System.out.println(A.getLatitude());
                                Location B = new Location("client");
                                B.setLongitude(lgt);
                                B.setLatitude(lat);


                              // B.setLongitude(currentLocation.getLongitude());
                               //B.setLatitude(currentLocation.getLatitude());
                                double distance = A.distanceTo(B);
                                System.out.println("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz" + distance);
                                myShop.distance = distance;
                                shopAttributes.add(myShop);
                            }
                        }
                    }
                    System.out.println("List size is "+shopAttributes.size());
                    //System.out.println(("Awel shop "+ shopAttributes.get(0).name));
                    NewAdapter adapter = new NewAdapter(shopAttributes, getApplicationContext());
                    SubjectListView.setAdapter(adapter);





                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                    System.out.println("Catch1");
                    Toast.makeText(getApplicationContext(), "Json error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }


            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("catch2");
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();
                //hideDialog();
            }

        });
        sortPrice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent i = new Intent(getApplicationContext(),
                        List3Activity.class);
                startActivity(i);
                finish();

            }
        });
        sortDistance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(getApplicationContext(),
                        List4Activity.class);
                startActivity(i);
                finish();

            }
        });
       MyCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),
                       CartList.class);
                startActivity(i);
                finish();
            }
        });





        AppController.getInstance().addToRequestQueue(str, tag_string_req);
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);



    }
   /* public void OnShopItemClick( final int position) {


        Double lat = shopAttributes.get(position).lat;
        Double lon = shopAttributes.get(position).lgt ;
        // setup the alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("options");
        // add the buttons
        builder.setPositiveButton("Navigate to location", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                //  Intent n = new Intent(CartActivity.this , MapsActivity.class) ;
                Double lat = shopAttributes.get(position).lat;
                Double lon = shopAttributes.get(position).lgt ;

                String q = "q= " + lat + ", " + lon;
                Uri gmmIntentUri = Uri.parse("google.navigation:" + q);
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        // create and show the alert dialog
        AlertDialog dialog = builder.create();
        dialog.show();

    }*/



    private void fetchLocation() {
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
            return;
        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    currentLocation = location;
                    lat=currentLocation.getLatitude();
                    lgt=currentLocation.getLongitude();
                    System.out.println("kkkkkkkkkkjjhh"+currentLocation.getLongitude());
                    //Toast.makeText(getApplicationContext(), currentLocation.getLatitude() + "" + currentLocation.getLongitude(), Toast.LENGTH_SHORT).show();

                }
            }
        });
    }
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    fetchLocation();
                }
                break;
        }
    }





    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }



}



