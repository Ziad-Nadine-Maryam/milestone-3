package activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.shoppy.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import app.AppController;

import static activity.List2Activity.db;

public class NewAdapter extends BaseAdapter {

    Context context;
    List<Shop> valueList;
    List<Shop> valist;

    public NewAdapter(List<Shop> listValue, Context context)
    {
        this.context = context;
        this.valueList = listValue;
    }

    @Override
    public int getCount()
    {
        return this.valueList.size();
    }

    @Override
    public Object getItem(int position)
    {
        return this.valueList.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }
    public View getView(final int position, View convertView, ViewGroup parent)
    {
        ViewItem2 viewItem = null;

        if(convertView == null)
        {
            viewItem = new ViewItem2();

            LayoutInflater layoutInfiater = (LayoutInflater)this.context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);

            convertView = layoutInfiater.inflate(R.layout.shoplist, null);

            viewItem.TextViewSubjectName = (TextView)convertView.findViewById(R.id.textView3);
            viewItem.AddToCart = (Button)convertView.findViewById(R.id.button);
            viewItem.AddToCart.setOnClickListener(new View.OnClickListener() {
                                                      @Override
                                                      public void onClick(View v) {
                                                          Shop shop = new Shop();
                                                          shop = valueList.get(position);
                                                          Cart cart = new Cart();
                                                         // cart.Shop_Id=shop.id;
                                                          cart.User_Id=MainActivity.userss[0];
                                                          cart.shop_id=shop.id;
                                                          cart.product_id=shop.pid;
                                                          System.out.println("mayaaaaaaaaaaaaa");

                                                          CartList.shopList.add(cart);
                                                          CartList.AddToCart(cart.User_Id,cart.shop_id,cart.product_id);
                                                      }
                                                  });



                    convertView.setTag(viewItem);
        }
        else
        {
            viewItem = (ViewItem2) convertView.getTag();
        }
        String s=toString(position);
        viewItem.TextViewSubjectName.setText(s);





        return convertView;
    }
    public  String toString( int position){
        return "Name: "+ valueList.get(position).name+ "\n " +"\n "+"Distance: "+ valueList.get(position).distance+ "\n " +"\n "+"Special Offers: "+valueList.get(position).special+ "\n " +"\n "+"Price: "+valueList.get(position).price+ "\n " +"\n ";
    }


}
class ViewItem2{
    TextView TextViewSubjectName;
    Button AddToCart;
}



