package activity;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.shoppy.R;

import java.util.List;

public class CartAdapter extends BaseAdapter {

    Context context;
    List<Cart> valueList;
    List<Cart> valist;

    public CartAdapter(List<Cart> listValue, Context context)
    {
        this.context = context;
        this.valueList = listValue;
    }

    @Override
    public int getCount()
    {
        return this.valueList.size();
    }

    @Override
    public Object getItem(int position)
    {
        return this.valueList.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }
    public View getView(final int position, View convertView, ViewGroup parent)
    {
        ViewItem2 viewItem = null;

        if(convertView == null)
        {
            viewItem = new ViewItem2();

            LayoutInflater layoutInfiater = (LayoutInflater)this.context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);

            convertView = layoutInfiater.inflate(R.layout.shoplist, null);

            viewItem.TextViewSubjectName = (TextView)convertView.findViewById(R.id.textView3);
            viewItem.AddToCart = (Button)convertView.findViewById(R.id.button);
            viewItem.AddToCart.setText("Remove");
            viewItem.AddToCart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Cart cart= new Cart();
                    cart = valueList.get(position);
                    CartList.shopList.remove(cart);
                    CartList.RemoveFromCart(cart.User_Id,cart.shop_id,cart.product_id);

                }
            });



            convertView.setTag(viewItem);
        }
        else
        {
            viewItem = (ViewItem2) convertView.getTag();
        }
        String s=toString(position);
        viewItem.TextViewSubjectName.setText(s);





        return convertView;
    }

    public  String toString( int position){
        return "Product: "+valueList.get(position).product_name+ "\n " +"\n "+ "Shop: "+ valueList.get(position).shop_name+ "\n " +"\n ";
    }

}




