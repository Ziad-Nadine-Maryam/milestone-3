package activity;

import java.util.Comparator;

public class DistanceComparator implements Comparator<Shop> {

    @Override
    public int compare(Shop o1, Shop o2) {
        if(o2.distance>=o1.distance)
            return -1;
        else
            return 1;
    }
}
